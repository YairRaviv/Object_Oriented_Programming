package api;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.*;

public class DWG_Algo implements dw_graph_algorithms
{
    private directed_weighted_graph graph;

    @Override
    public void init(directed_weighted_graph g)
    {
        this.graph=g;
    }

    @Override
    public directed_weighted_graph getGraph()
    {
        return this.graph;
    }

    @Override
    public directed_weighted_graph copy()
    {
        directed_weighted_graph g=new DW_Graph(this.graph);
        return g;
    }

    @Override
    public boolean isConnected()
    {
        Iterator<node_data> itr1=this.graph.getV().iterator();
        while(itr1.hasNext())
        {
            node_data n= itr1.next();
            Iterator<node_data> itr2=this.graph.getV().iterator();
            while(itr2.hasNext())
            {
                if(this.shortestPathDist(n.getKey(),itr2.next().getKey())==-1)return false;
            }
        }
        return true;
    }

    @Override
    public double shortestPathDist(int src, int dest)
    {
        if(src==dest)return 0;
        if(null==shortestPath(src,dest))return -1;
        List<node_data> path=shortestPath(src,dest);
        if(path.size()==0)return -1;
        double length=0;
        Iterator<node_data> itr =path.iterator();
        node_data tmp=itr.next();
        while(itr.hasNext())
        {
            node_data tmp1= itr.next();
            length+=getGraph().getEdge(tmp.getKey(), tmp1.getKey()).getWeight();
            tmp=tmp1;
        }
        return length;
    }

    @Override
    public List<node_data> shortestPath(int src, int dest)
    {
        HashMap<Integer,Double> dis=new HashMap<>();
        HashMap<Integer,Boolean> vis=new HashMap<>();
        Queue<Integer> q=new LinkedList<>();
        HashMap<Integer, node_data> Path =new HashMap<>();
        ArrayList<node_data> rev=new ArrayList<>();
        ArrayList<node_data> ans =new ArrayList<>();
        if(src==dest||null==graph.getNode(src)||null==graph.getNode(dest))return null;

        Iterator<node_data> itr1=this.graph.getV().iterator();
        while(itr1.hasNext())
        {
            node_data tmp1= itr1.next();
            if(tmp1.getKey()!=src)
            {
                dis.put(tmp1.getKey(),Double.MAX_VALUE);
            }
            else dis.put(tmp1.getKey(),0.0);
        }
        q.add(src);
        while(!q.isEmpty())
        {
            node_data curr=graph.getNode(q.poll());
            if(null==vis.get(curr.getKey()))
            {
                vis.put(curr.getKey(),true);
                Iterator<edge_data> itr2=graph.getE(curr.getKey()).iterator();
                while(itr2.hasNext())
                {
                    edge_data e=itr2.next();
                    node_data tmp2=graph.getNode(e.getDest());
                    if(null==vis.get(tmp2.getKey()))q.add(tmp2.getKey());
                    double d=graph.getEdge(curr.getKey(), tmp2.getKey()).getWeight();
                    if(d+dis.get(curr.getKey())< dis.get(tmp2.getKey()))
                    {
                        dis.put(tmp2.getKey(),d+dis.get(curr.getKey()));
                        Path.put(tmp2.getKey(),curr);
                    }
                }

            }
        }
        if(null==Path.get(dest))return ans;
        rev.add(graph.getNode(dest));
        int tmp=dest;
        while(tmp!=src)
        {
            rev.add(Path.get(tmp));
            tmp=Path.get(tmp).getKey();
        }

        if(rev.size()<=1)return rev;
        int tmp2= rev.size()-1;
        while (tmp2>=0)
        {
            ans.add(rev.get(tmp2));
            tmp2--;
        }
        return ans;
    }



    @Override
    public boolean save(String file)
    {
       Gson gson=new GsonBuilder().setPrettyPrinting().create();
       String MyJson=gson.toJson(getGraph());
       try
       {
           PrintWriter p=new PrintWriter(file);
           p.write(MyJson);
           p.close();
           return true;
       }
       catch (FileNotFoundException e)
       {
           e.printStackTrace();
       }
        // serialize();
        return false;
    }

    @Override
    public boolean load(String file)
    {

        GsonBuilder b=new GsonBuilder();
        b.registerTypeAdapter(DW_Graph.class,new DW_Graph.deserializer());
        Gson gg=b.create();

        try
        {
            FileReader r = new FileReader(file);
            DW_Graph g=gg.fromJson(r,DW_Graph.class);
            init(g);
            return true;
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        return false;
    }




}
