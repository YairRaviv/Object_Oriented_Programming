
package gameClient;

import Server.Game_Server_Ex2;
import api.*;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Ex2 implements Runnable
{
    private static MyFrame myFrame;
    private static MyArena myArena;

    public static void main(String[] a)
    {
        Thread client = new Thread(new gameClient.Ex2());
        client.start();
        int x=1;


    }

    @Override
    public void run()
    {
        game_service game = Game_Server_Ex2.getServer(14);
        directed_weighted_graph current_game_graph = game.getJava_Graph_Not_to_be_used();
        init(game);
        game.startGame();
        //myFrame.setTitle("Ex2 - OOP: (NONE trivial Solution) "+game.toString());
        int ind=0;
        long dt=99;

        while(game.isRunning())
        {
            myArena.moveAgants(game, current_game_graph);
            try
            {
                if(ind%1==0)
                {
                    myFrame.repaint();
                    myArena.setTime(game.timeToEnd());
                }
                Thread.sleep(dt);
                ind++;
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        String res = game.toString();

        System.out.println(res);
        System.exit(0);
    }




    private void init(game_service game)
    {
        String String_game_graph= game.getGraph();
        String String_game_pokemons = game.getPokemons();
        directed_weighted_graph current_game_graph = game.getJava_Graph_Not_to_be_used();

        myArena = new MyArena();
        myArena.setGraph(current_game_graph);
        myArena.setPokemons(MyArena.json2Pokemons(String_game_pokemons));
        myFrame = new MyFrame("test Ex2");
        myFrame.setSize(1000, 700);
        myFrame.update(myArena);
        myFrame.setVisible(true);

        String info = game.toString();
        JSONObject json_of_game;
        try
        {
            json_of_game = new JSONObject(info);
            JSONObject json_game_server = json_of_game.getJSONObject("GameServer");
            int agents_num = json_game_server.getInt("agents");
            int src_node = 0;  // arbitrary node, you should start at one of the pokemon
            ArrayList<CL_Pokemon> game_pokemons = MyArena.json2Pokemons(String_game_pokemons);

            for(int a = 0;a<game_pokemons.size();a++)
            {
                MyArena.updateEdge(game_pokemons.get(a),current_game_graph);
            }


            /**
             * first of all,get a sorted list of pokemons(by values)
             * and a sorted list of agents(by speed)
             */
            List<CL_Pokemon> pokemons=sort_pokemons(game_pokemons);
            String Agents=game.getAgents();
            List<CL_Agent> sorted_agents=sort_agents(myArena.getAgents(Agents,current_game_graph));

            int i=0;



            /**
             * init the first set of agents ,one per pokemon
             * the highest pokemon get the fastest agent
             */
            for(int a = 0;a<agents_num;a++)
            {
                int pokemons_num = pokemons.size();
                CL_Pokemon c = pokemons.get(a);
                int init_pos = c.get_edge().getDest();
                if(c.getType()<0 ) {init_pos = c.get_edge().getSrc();}
                System.out.println("position is:"+init_pos);
                game.addAgent(init_pos);
                i=a;
                if(a==pokemons_num)break;
            }

            /**
             * init the rest of the agents
             * every agent get the max distance from the other agents
             */
            DWG_Algo dwga=new DWG_Algo();
            dwga.init(current_game_graph);
            while(i<agents_num)
            {
                int max=0;
                double max_distance=0;
                for(int j=0;j<i;j++)
                {

                    if(sorted_agents.size()==0)break;
                    CL_Agent tmp=sorted_agents.get(j);
                    Iterator<node_data> itr=current_game_graph.getV().iterator();
                    while(itr.hasNext())
                    {
                        int node=itr.next().getKey();
                        if(dwga.shortestPathDist(tmp.getSrcNode(),node)/tmp.getSpeed()>max_distance)
                        {
                            max=node;
                            max_distance=dwga.shortestPathDist(tmp.getSrcNode(),node)/tmp.getSpeed();
                        }
                    }

                }
                game.addAgent(max);
                i++;
            }

        }
        catch (JSONException e) {e.printStackTrace();}
    }


    /**
     * sort functions
     * @param game_pokemons
     * @return
     */
    private List<CL_Pokemon> sort_pokemons(ArrayList<CL_Pokemon> game_pokemons)
    {
        CL_Pokemon [] arr=new CL_Pokemon[game_pokemons.size()];
        for(int i=0;i<arr.length;i++)
        {
            arr[i]=game_pokemons.get(i);
        }

        for(int i=0;i< arr.length;i++)
        {
            for(int j=i+1;j<arr.length-1;j++)
            {
                if(arr[j].getValue()>arr[i].getValue())
                {
                    CL_Pokemon tmp=arr[j];
                    arr[j]=arr[i];
                    arr[i]=tmp;
                }
            }
        }
        List<CL_Pokemon> ans=new ArrayList<>();
        for(int i=0;i<arr.length;i++)
        {
            ans.add(arr[i]);
        }
        return ans;
    }


    public List<CL_Agent> sort_agents(List<CL_Agent> list)
    {
        CL_Agent[] arr=new CL_Agent[list.size()];
        for(int i=0;i<arr.length;i++)
        {
            arr[i]=list.get(i);
        }

        for(int i=0;i< arr.length;i++)
        {
            for(int j=i+1;j<arr.length-1;j++)
            {
                if(arr[j].getSpeed()>arr[i].getSpeed())
                {
                    CL_Agent tmp=arr[j];
                    arr[j]=arr[i];
                    arr[i]=tmp;
                }
            }
        }
        List<CL_Agent> ans=new ArrayList<>();
        for(int i=0;i<arr.length;i++)
        {
            ans.add(arr[i]);
        }
        return ans;
    }
}



